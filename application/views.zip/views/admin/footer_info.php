<footer class="main-footer" style="background: #000; color: #fff;">
	<div class="pull-right hidden-xs">
	  <b>Design n Developed By</b> <a href="https://www.adinfoworld.com" target="_blank"><strong>AD Infoworld</strong></a>
	</div>
	<strong>Copyright &copy; <?php echo date('Y'); ?> <a href="<?php echo site_url();?>" target="_blank"> &nbsp;&nbsp;&nbsp;&nbsp;Company Discount Shop</a>. &nbsp;&nbsp;&nbsp;&nbsp;</strong> All rights reserved.
</footer>