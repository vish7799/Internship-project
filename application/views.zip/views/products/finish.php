
<div class="breadcrumbs-v4">
	<div class="container">
		
		<h1>Thanks for your<span class="shop-green">Order</span></h1>
		<ul class="breadcrumb-v4-in">
			<li><a href="index.html">Home</a></li>
			<li><a href="">Product</a></li>
			<li class="active">Complete</li>
		</ul>
	</div>
</div>


<div class="container content">
	<div class="heading heading-v1 margin-bottom-40">
		<h2 style="color:#000; font-size:32px; line-height:2; ">Thanks For Your Order</h2>
		<p style="color:#000; font-size:16px; line-height:2; ">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed odio elit, ultrices vel cursus sed, placerat ut leo. Phasellus in magna erat. Etiam gravida convallis augue non tincidunt. Nunc lobortis dapibus neque quis lacinia. Nam dapibus tellus sit amet odio venenatis</p>
		<button style="text-align:center; padding:10px ; font-size:20px; font-weight:bold; margin-top:20px;" type="button" class="btn-u btn-u-sea-shop">Shopping</button>
		<button style="text-align:center; padding:10px ; font-size:20px; font-weight:bold; margin-top:20px;" type="button" class="btn-u btn-u-sea-shop">My Account</button>
	</div>
</div>	
		
