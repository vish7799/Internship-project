<div class="breadcrumbs-v4" style="background: url(<?php echo site_url(); ?>assets/img/p_head.jpg) no-repeat; background-position: center; padding-top:5px; padding-bottom:5px;">
	<div class="container">
		<ul class="breadcrumb-v4-in">
			<li><a href="index.html">Home</a></li>
			<li class="active">Booking</li>
		</ul>
	</div>
</div>

<div class="container" style="padding-top: 60px; padding-bottom: 60px;">	
	<div class="row">
		<div class="col-md-12" >
			<div style="box-shadow: 0 1px 8px rgb(0 0 0 / 18%);  margin-bottom: 40px; background-color: #fff; padding: 20px; text-align: center;">
				<span class="text-center" style="color:#E8308B; font-size: 45px; font-family: berthessa; font-weight:bold; text-transform: capitalize;">Golden World</span>
				
				<p class="text-center" style="padding-top:25px;"><?php echo $respmsg; ?></p>
			</div>
		</div>
	</div>
</div>
	