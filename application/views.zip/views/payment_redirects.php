<html>
<head>
<title>Merchant Check Out Page</title>
</head>
<body>
<?php //pr($paramList['CHECKSUMHASH']); die; ?>
	<center><h1>Please do not refresh this page...</h1></center>
		<form method="post" action="<?php echo PAYTM_TXN_URL ?>" name="f1">
		<!--<form method="post" action="https://securegw-stage.paytm.in/order/process" name="f1"> -->
		<table border="1">
			<tbody>
			<?php

			foreach($paramList as $name => $value) {
				echo '<input type="hidden" name="' . $name .'" value="' . $value . '">';
			}
			
			?>
			<input type="hidden" name="CHECKSUMHASH" value="<?php echo $paramList['CHECKSUMHASH'] ?>">
			</tbody>
		</table>
		<script type="text/javascript">
			document.f1.submit();
		</script>
	</form>
</body>
</html>